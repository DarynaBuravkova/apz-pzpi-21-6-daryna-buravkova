﻿namespace BeanBlissAPI
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
