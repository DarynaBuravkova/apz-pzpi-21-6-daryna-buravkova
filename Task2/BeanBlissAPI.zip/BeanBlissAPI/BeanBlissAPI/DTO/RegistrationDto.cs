﻿namespace BeanBlissAPI.DTO
{
    public class RegistrationDto
    {
        public string Email { get; set; }
        public string Role { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
    }
}
